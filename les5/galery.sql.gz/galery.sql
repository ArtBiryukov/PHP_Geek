-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1
-- Время создания: Дек 07 2021 г., 12:36
-- Версия сервера: 10.4.21-MariaDB
-- Версия PHP: 8.0.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `galery`
--

-- --------------------------------------------------------

--
-- Структура таблицы `images`
--

CREATE TABLE `images` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `url_images` varchar(255) NOT NULL,
  `pice` int(11) NOT NULL,
  `view` int(11) DEFAULT 0,
  `description` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Дамп данных таблицы `images`
--

INSERT INTO `images` (`id`, `title`, `url_images`, `pice`, `view`, `description`) VALUES
(1, 'BMW', '1.jpg', 10000, 3, 'Немецкий производитель автомобилей, мотоциклов, двигателей, а также велосипедов. '),
(2, 'Chevrolet Mustang', '2.jpg', 5000, 1, 'Марка автомобилей, производимых и реализуемых одноимённым экономически самостоятельным подразделением корпорации General Motors. Chevrolet является самой популярной среди марок концерна GM: в 2007 году было реализовано около 2,6 млн автомобилей.'),
(3, 'lamborghini', '3.jpg', 15000, 0, 'Automobili Lamborghini S.p.A. - итальянская компания, производитель дорогих спортивных автомобилей под маркой Lamborghini. Находится в коммуне Сант-Агата-Болоньезе, около Болоньи. '),
(4, 'Porsche', '4.jpg', 8000, 8, 'Немецкий производитель автомобилей и солнцезащитных очков, основанный конструктором Фердинандом Порше в 1931 году. Штаб-квартира и основной завод находятся в Штутгарте, Германия.'),
(5, 'Ferrari', '5.jpg', 9000, 2, 'Ferrari NV — итальянская компания, выпускающая спортивные и гоночные автомобили, базирующаяся в Маранелло. '),
(6, 'Chevrolet Camaro', '6.jpg', 6000, 6, 'Американский мускулистый автомобиль, «muscle car», выпускающийся подразделением Chevrolet корпорации General Motors с 1966 года.');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `images`
--
ALTER TABLE `images`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `images`
--
ALTER TABLE `images`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
